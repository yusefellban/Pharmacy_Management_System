package Pharmacy;

public class Product {
    private String ProductName;
    private String ProductType;
    private String SupplierName;
    private double ProductUnitPrice;
    private int Quantity;
    public Product(){}

}
