package Pharmacy;

import java.sql.Date;
import java.text.DateFormat;

public class PaymentCard {
    private String CardType;
    private Date ExpiredDate;
    private double CardMount;
    private int CardNumber;
    private int CardPassword;
    public PaymentCard(){}

}
