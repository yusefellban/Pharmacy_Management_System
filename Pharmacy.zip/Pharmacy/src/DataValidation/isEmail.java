package DataValidation;

public interface isEmail{
    void is_Email();
}
