package DataValidation;

public interface isExist {
    void is_Exists();
}
