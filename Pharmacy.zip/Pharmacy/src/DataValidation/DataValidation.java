package DataValidation;

public interface DataValidation {
    boolean EmailValidation(isEmail email);
    boolean ExistsOnDatabase(isExist obj);

}
